const Botaodeleta =()=>{
    const botaodeleta= document.createElement('button')
    Botaodeleta.innerText='Deletar' //recebendo um nome
    botaodeleta.classList.add('check-button')
    botaodeleta.innerText='deletar'
    botaodeleta.addEventListener('click', deletartarefa)
    
    return botaodeleta

}
const deletartarefa=(evento)=>{
 const  botaodeleta=evento.target //pegando o alvo dele
 const tarefaCompleta= botaodeleta.parentElement //pegando o pai do elemento para exc
//luir  a frase e nao o elemento
 tarefaCompleta.remove() //removendo elemento da arvore, no caso vai excluir  o que eu digitei
 return botaodeleta
}


export default Botaodeleta

//trabalhando com modulos
// Módulos são pequenas partes do código que juntas formam um todo. 
//exporto para importar em outro lugar