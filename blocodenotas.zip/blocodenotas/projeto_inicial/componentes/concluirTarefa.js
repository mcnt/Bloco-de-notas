const Botaoconcluir=()=>{
    const botaoconclui=document.createElement('button')
    botaoconclui.classList.add('check-button')
    botaoconclui.innerText='concluir' //adicionando texto
    botaoconclui.addEventListener("click", concluiTarefa)
        
    return botaoconclui
    }

    const concluiTarefa=(evento)=>{
    const botaoconclui=evento.target
    const tarefaCompleta=botaoconclui.parentElement //pegando o pai do elemento
    tarefaCompleta.classList.toggle("done") //verdadeiro ou falso "toggle"
    
    }

export default Botaoconcluir
//Caso expor os dois seria: export{
    //a
    //
//}