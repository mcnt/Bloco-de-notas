// tirando do global iife= (()=>{   
// })()

import Botaoconcluir from "./componentes/concluirTarefa.js"
import Botaodeleta from "./componentes/deletarTarefa.js"


        const criarTarefa= (evento)=>{ //criando um evento
        evento.preventDefault()
        const lista=document.querySelector('[data-list]')
        const input=document.querySelector('[data-form-input]')
        const valor=input.value
            
        const tarefa= document.createElement('li') //criando elemento
        tarefa.classList.add('task') // acessando css classlist e add para adicionar a classe do js
        const conteudo=`<p class="content">${valor}</p>` //acessando elementos do html ´elemento, ${x}
        
        tarefa.innerHTML = conteudo
        tarefa.appendChild(Botaoconcluir())
        tarefa.appendChild(Botaodeleta())
        lista.appendChild(tarefa) //colocando elemento na lista
        input.value=" "

        }
        
    
        const novaTarefa= document.querySelector('[data-form-button]')
        
        novaTarefa.addEventListener("click", criarTarefa)
            
        
    


